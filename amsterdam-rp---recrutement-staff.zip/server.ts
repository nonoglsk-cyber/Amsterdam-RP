import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { dbStore } from './database';
import { StaffRole, ApplicationStatus } from './src/types';

// Charger les variables d'environnement
import dotenv from 'dotenv';
dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Stockage en mémoire des sessions
const SESSIONS: Record<string, { userId: string }> = {};

// Helper pour extraire l'utilisateur courant de la session
const getSessionUser = (req: express.Request) => {
  const cookieHeader = req.headers.cookie || '';
  const match = cookieHeader.match(/staff_candidacy_session=([^;]+)/);
  if (!match) return null;
  const token = match[1];
  const session = SESSIONS[token];
  if (!session) return null;
  return dbStore.getUser(session.userId);
};

// Middleware d'authentification requis
const requireAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const user = getSessionUser(req);
  if (!user) {
    res.status(401).json({ error: 'Non authentifié. Veuillez vous connecter.' });
    return;
  }
  (req as any).user = user;
  next();
};

// Middleware de vérification des permissions
const requireRole = (allowedRoles: StaffRole[]) => {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const user = (req as any).user;
    if (!user) {
      res.status(401).json({ error: 'Non authentifié.' });
      return;
    }

    const roleRank: Record<StaffRole, number> = {
      'user': 0,
      'modo': 1,
      'admin': 2,
      'gerant': 3,
      'fondation': 4
    };

    const userRank = roleRank[user.role] || 0;
    const minRequiredRank = Math.min(...allowedRoles.map(r => roleRank[r]));

    if (userRank >= minRequiredRank) {
      next();
    } else {
      res.status(403).json({
        error: `Accès refusé. Niveau requis: ${allowedRoles.map(r => r.toUpperCase()).join(' / ')} (Votre rôle actuel: ${user.role.toUpperCase()})`
      });
    }
  };
};

// Discord Webhook helper
async function sendDiscordWebhook(embed: {
  title: string;
  description: string;
  color: number;
  fields?: { name: string; value: string; inline?: boolean }[];
  thumbnail?: { url: string };
  timestamp?: string;
  footer?: { text: string };
}) {
  const webhookUrl = process.env.DISCORD_WEBHOOK_URL;
  if (!webhookUrl) {
    console.log('\n--- [Notification Simulation WEBHOOK DISCORD] ---');
    console.log(`Embed Title: ${embed.title}`);
    console.log(`Description: ${embed.description}`);
    if (embed.fields) {
      console.log('Fields:', JSON.stringify(embed.fields, null, 2));
    }
    console.log('--------------------------------------------------\n');
    return;
  }

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        embeds: [
          {
            ...embed,
            timestamp: embed.timestamp || new Date().toISOString(),
            footer: embed.footer || { text: 'Emergency Hamburg - Plateforme Recrutement Staff' },
          },
        ],
      }),
    });
    if (!response.ok) {
      console.error('Erreur lors de l\'envoi du webhook Discord:', response.statusText);
    }
  } catch (error) {
    console.error('Erreur réseau lors de l\'envoi du webhook Discord:', error);
  }
}

// ==========================================
// REAL-TIME SYNCHRONIZATION (SSE)
// ==========================================
let sseClients: { id: number; res: express.Response }[] = [];

function broadcastRealtimeEvent(type: string, payload: any = {}) {
  const dataString = JSON.stringify({ type, timestamp: new Date().toISOString(), ...payload });
  sseClients.forEach((client) => {
    try {
      client.res.write(`data: ${dataString}\n\n`);
    } catch (e) {
      console.error("Erreur diffusion SSE client", client.id, e);
    }
  });
}

app.get('/api/realtime/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();

  const clientId = Date.now();
  const newClient = { id: clientId, res };
  sseClients.push(newClient);

  // Send successful connection
  res.write(`data: ${JSON.stringify({ type: 'welcome', clientId, message: 'Connexion Amsterdam RP EventStream établie.' })}\n\n`);

  req.on('close', () => {
    sseClients = sseClients.filter(c => c.id !== clientId);
  });
});

// ==========================================
// API ROUTES
// ==========================================

// Statut d'authentification
app.get('/api/auth/me', (req, res) => {
  const user = getSessionUser(req);
  if (!user) {
    res.json({ user: null });
    return;
  }
  res.json({ user });
});

// Connexion de simulation (Développement / Démo sans API Keys)
app.post('/api/auth/simulation', async (req, res) => {
  const { userId, username, avatar, role } = req.body;
  if (!userId || !username) {
    res.status(400).json({ error: 'Champs userId et username requis.' });
    return;
  }

  // Vérifier si l'utilisateur est pré-enregistré dans la base de données
  const existingUser = dbStore.getUser(userId);
  if (!existingUser) {
    res.status(403).json({
      error: `Votre ID Discord (${userId}) n'a pas été pré-enregistré par les Fondations / Owners d'Amsterdam RP. Veuillez vous rapprocher d'un propriétaire.`
    });
    return;
  }

  let finalUsername = username;
  let finalAvatar = avatar || 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&h=150';

  // Si le client a déjà résolu un profil réel de Discord (indiqué par un avatar Discord réel), on évite un fetch inutile qui échouera sur le serveur sandbloqué
  const isAlreadyResolved = avatar && (avatar.includes('discordapp.com') || avatar.includes('embed/avatars'));

  // Tentative de résolution du vrai profil Discord si l'identifiant est réaliste numérique et non résolu
  if (!isAlreadyResolved && userId && /^\d{17,21}$/.test(userId)) {
    let resolved = false;

    // Méthode 1 : Discord Bot Token (Officiel)
    if (process.env.DISCORD_BOT_TOKEN) {
      try {
        const dResponse = await fetch(`https://discord.com/api/v10/users/${userId}`, {
          headers: {
            'Authorization': `Bot ${process.env.DISCORD_BOT_TOKEN}`
          }
        });
        if (dResponse.ok) {
          const dUser = await dResponse.json();
          if (dUser && dUser.username) {
            finalUsername = dUser.global_name || dUser.username;
            if (dUser.avatar) {
              finalAvatar = `https://cdn.discordapp.com/avatars/${userId}/${dUser.avatar}.png`;
            } else {
              const defaultAvatarId = dUser.discriminator && dUser.discriminator !== '0'
                ? parseInt(dUser.discriminator) % 5
                : Number(BigInt(userId) >> 22n) % 6;
              finalAvatar = `https://cdn.discordapp.com/embed/avatars/${defaultAvatarId}.png`;
            }
            resolved = true;
            console.log(`[Discord Link] Profil Discord réel résolu pour ${finalUsername} via BOT Token.`);
          }
        }
      } catch (err) {
        console.error("Erreur résolution ID Discord via BOT Token:", err);
      }
    }

    // Méthode 2 : API Publique Lanyard (Alternative sans clé si l'utilisateur y est inscrit)
    if (!resolved) {
      try {
        const lanyardRes = await fetch(`https://api.lanyard.rest/v1/users/${userId}`);
        if (lanyardRes.ok) {
          const lData = await lanyardRes.json();
          if (lData.success && lData.data && lData.data.discord_user) {
            const dUser = lData.data.discord_user;
            finalUsername = dUser.global_name || dUser.username;
            if (dUser.avatar) {
              finalAvatar = `https://cdn.discordapp.com/avatars/${userId}/${dUser.avatar}.png`;
            } else {
              const defaultAvatarId = dUser.discriminator && dUser.discriminator !== '0'
                ? parseInt(dUser.discriminator) % 5
                : Number(BigInt(userId) >> 22n) % 6;
              finalAvatar = `https://cdn.discordapp.com/embed/avatars/${defaultAvatarId}.png`;
            }
            resolved = true;
            console.log(`[Discord Link] Profil Discord réel résolu pour ${finalUsername} via Lanyard API.`);
          }
        }
      } catch (err) {
        // Ignorer silencieusement si Lanyard échoue
      }
    }

    // Méthode 3 : API Publique Mesalytic (Excellent proxy universel gratuit sans authorization requis)
    if (!resolved) {
      try {
        const mesaRes = await fetch(`https://discordlookup.mesalytic.workers.dev/v1/user/${userId}`);
        if (mesaRes.ok) {
          const mData = await mesaRes.json();
          if (mData && mData.username) {
            finalUsername = mData.global_name || mData.username;
            if (mData.avatar && mData.avatar.link) {
              finalAvatar = mData.avatar.link;
            } else if (mData.raw && mData.raw.avatar) {
              finalAvatar = `https://cdn.discordapp.com/avatars/${userId}/${mData.raw.avatar}.png`;
            } else {
              const defaultAvatarId = Number(BigInt(userId) >> 22n) % 6;
              finalAvatar = `https://cdn.discordapp.com/embed/avatars/${defaultAvatarId}.png`;
            }
            resolved = true;
            console.log(`[Discord Link] Profil Discord réel résolu pour ${finalUsername} via Mesalytic API.`);
          }
        }
      } catch (err) {
        // Logué en mode moins intrusif pour éviter de polluer le terminal si hors-ligne
        console.log(`[Discord Link Info] Résolution serveur impossible pour ID ${userId} (pas de connexion internet sur le serveur).`);
      }
    }

    // Méthode 4 : S'il n'y a pas d'avatar réel résolu, on calcule l'avatar Discord par défaut
    if (!resolved) {
      const defaultAvatarId = Number(BigInt(userId) >> 22n) % 6;
      finalAvatar = `https://cdn.discordapp.com/embed/avatars/${defaultAvatarId}.png`;
    }
  }

  const user = dbStore.getOrCreateUser(userId, finalUsername, finalAvatar);
  
  // Si un rôle spécifique est demandé et que c'est un compte prédéfini, l'assigner
  if (role) {
    user.role = role as StaffRole;
    dbStore.promoteUser(user.id, role as StaffRole, 'system', 'Console Développeur');
  }

  // Créer une session
  const token = 'sim_session_' + Math.random().toString(36).substring(2) + Date.now();
  SESSIONS[token] = { userId: user.id };

  // Notification Webhook Discord sur connexion
  await sendDiscordWebhook({
    title: '🔑 Connexion Session Établie (Simulation sandbox)',
    description: `Un utilisateur vient d'établir sa liaison de session sur le portail d'Amsterdam RP.`,
    color: 0x06B6D4, // Cyber Cyan
    fields: [
      { name: 'Pseudo', value: `**${user.username}**`, inline: true },
      { name: 'ID Discord Utilisateur', value: `\`${user.id}\``, inline: true },
      { name: 'Grade / Rôle d\'Accès', value: `\`${user.role.toUpperCase()}\``, inline: true }
    ],
    thumbnail: user.avatar ? { url: user.avatar } : undefined,
  });

  res.setHeader('Set-Cookie', `staff_candidacy_session=${token}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
  res.json({ success: true, user });
});

// Déconnexion
app.post('/api/auth/logout', (req, res) => {
  const cookieHeader = req.headers.cookie || '';
  const match = cookieHeader.match(/staff_candidacy_session=([^;]+)/);
  if (match) {
    const token = match[1];
    delete SESSIONS[token];
  }
  res.setHeader('Set-Cookie', 'staff_candidacy_session=; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=0');
  res.json({ success: true });
});

// Fonction d'aide pour calculer le redirect_uri de manière dynamique et robuste (spécialement pour Cloud Run)
const getDynamicRedirectUri = (req: express.Request) => {
  const xForwardedHost = req.headers['x-forwarded-host'];
  const xForwardedProto = req.headers['x-forwarded-proto'] || 'https';
  
  let currentHost = '';
  let currentProtocol = 'https';
  
  if (xForwardedHost) {
    currentHost = Array.isArray(xForwardedHost) ? xForwardedHost[0] : (xForwardedHost as string);
    currentProtocol = (Array.isArray(xForwardedProto) ? xForwardedProto[0] : (xForwardedProto as string)) || 'https';
  } else {
    currentHost = req.get('host') || '';
    currentProtocol = req.secure ? 'https' : 'http';
  }
  
  const isLocalRequest = currentHost.includes('localhost') || currentHost.includes('127.0.0.1');
  
  if (isLocalRequest) {
    currentProtocol = 'http';
  } else {
    currentProtocol = 'https';
  }
  
  // Utiliser la route demandée par Discord ou de base
  const callbackPath = req.path.includes('/initiate') ? '/api/auth/callback' : req.path;
  
  // Si DISCORD_REDIRECT_URI est forcé dans les variables d'environnement
  const envRedirectUri = process.env.DISCORD_REDIRECT_URI || '';
  if (envRedirectUri) {
    const isEnvRedirectLocal = envRedirectUri.includes('localhost') || envRedirectUri.includes('127.0.0.1');
    // Si la requête courante est locale et l'env est local, on l'utilise.
    // Si la requête courante est publique et l'env est publique, on l'utilise.
    if (isLocalRequest && isEnvRedirectLocal) {
      return envRedirectUri;
    }
    if (!isLocalRequest && !isEnvRedirectLocal) {
      return envRedirectUri;
    }
    // Si on est sur Cloud Run (visite distante) mais que la config est localhost, on l'ignore 
    // et on génère dynamiquement l'URL distante pour éviter que le navigateur ne bloque sur localhost:3000
  }
  
  if (currentHost) {
    return `${currentProtocol}://${currentHost}${callbackPath}`;
  }
  
  if (process.env.APP_URL) {
    return `${process.env.APP_URL.replace(/\/$/, '')}${callbackPath}`;
  }
  
  return `http://localhost:3000${callbackPath}`;
};

// Démarrer Discord OAuth2
app.get('/api/auth/discord/initiate', (req, res) => {
  const clientId = process.env.DISCORD_CLIENT_ID;
  const redirectUri = getDynamicRedirectUri(req);
  
  if (!clientId) {
    res.status(400).json({
      error: 'ID Client Discord non configuré dans les secrets d\'Amsterdam RP. Veuillez renseigner DISCORD_CLIENT_ID et DISCORD_CLIENT_SECRET dans la configuration.',
      simModeRecommended: false
    });
    return;
  }

  const authorizeUrl = `https://discord.com/api/oauth2/authorize?client_id=${clientId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=identify`;
  res.redirect(authorizeUrl);
});

// Callback Discord OAuth2 (supporte l'alias historique /api/auth/callback/discord de certains bots)
app.get(['/api/auth/callback', '/api/auth/callback/discord'], async (req, res) => {
  const { code } = req.query;
  if (!code) {
    res.redirect('/');
    return;
  }

  const clientId = process.env.DISCORD_CLIENT_ID;
  const clientSecret = process.env.DISCORD_CLIENT_SECRET;
  const redirectUri = getDynamicRedirectUri(req);

  if (!clientId || !clientSecret) {
    res.status(500).send('Identifiants Discord configurés incorrectement.');
    return;
  }

  try {
    // 1. Obtenir le jeton d'accès
    const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: 'authorization_code',
        code: code as string,
        redirect_uri: redirectUri,
      }),
    });

    if (!tokenResponse.ok) {
      const errText = await tokenResponse.text();
      throw new Error(`Discord Token Error: ${errText}`);
    }

    const tokenData = await tokenResponse.json();
    const accessToken = tokenData.access_token;

    // 2. Récupérer l'utilisateur Discord
    const userResponse = await fetch('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${accessToken}` },
    });

    if (!userResponse.ok) {
      throw new Error('Impossible de charger les données utilisateur Discord');
    }

    const discordUser = await userResponse.json();

    // Vérifier si l'ID de l'utilisateur est pré-enregistré dans notre base de données par l'un des propriétaires
    const existingUser = dbStore.getUser(discordUser.id);
    if (!existingUser) {
      res.status(403).send(`
        <html>
          <head>
            <title>Accès Refusé - Amsterdam RP</title>
            <style>
              body {
                background: #090d16;
                color: #f1f5f9;
                font-family: system-ui, -apple-system, sans-serif;
                display: flex;
                align-items: center;
                justify-content: center;
                height: 100vh;
                margin: 0;
                text-align: center;
              }
              .card {
                background: rgba(239, 68, 68, 0.03);
                backdrop-filter: blur(12px);
                padding: 2.5rem;
                border-radius: 1.25rem;
                border: 1px solid rgba(239, 68, 68, 0.2);
                box-shadow: 0 20px 40px rgba(0,0,0,0.5);
                max-width: 420px;
              }
              h1 { font-size: 1.35rem; font-weight: 800; margin-bottom: 0.75rem; color: #f43f5e; text-transform: uppercase; letter-spacing: 0.025em; }
              p { font-size: 0.85rem; color: #94a3b8; line-height: 1.5; }
              .id-box {
                background: rgba(0,0,0,0.5);
                padding: 0.75rem;
                border-radius: 0.5rem;
                font-family: monospace;
                font-size: 0.85rem;
                color: #f43f5e;
                margin: 1.5rem 0;
                border: 1px solid rgba(239, 68, 68, 0.1);
              }
              .btn {
                display: inline-block;
                margin-top: 1.5rem;
                background: rgba(255, 255, 255, 0.05);
                color: #cbd5e1;
                border: 1px solid rgba(255, 255, 255, 0.1);
                padding: 0.55rem 1.1rem;
                border-radius: 0.375rem;
                text-decoration: none;
                font-size: 0.8rem;
                font-weight: 600;
                transition: all 0.2s;
              }
              .btn:hover {
                background: rgba(255, 255, 255, 0.1);
                color: #fff;
              }
            </style>
          </head>
          <body>
            <div class="card">
              <h1>Accès non autorisé</h1>
              <p>Votre Snowflake Discord n'est pas pré-enregistré dans la hiérarchie d'accès par la Fondation d'Amsterdam RP.</p>
              <div class="id-box">ID : ${discordUser.id}</div>
              <p style="font-size: 11px; color: #64748b;">Veuillez contacter un Owner de l'île pour vous pré-inscrire sur la liste blanche.</p>
              <a href="/" class="btn">Retour au portail de connexion</a>
            </div>
          </body>
        </html>
      `);
      return;
    }

    // Construction de l'avatar Discord
    let avatarUrl = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150';
    if (discordUser.avatar) {
      avatarUrl = `https://cdn.discordapp.com/avatars/${discordUser.id}/${discordUser.avatar}.png`;
    }

    const username = discordUser.discriminator && discordUser.discriminator !== '0'
      ? `${discordUser.username}#${discordUser.discriminator}`
      : discordUser.username;

    // Optionnel: Récupérer les rôles si un bot est configuré, sinon le premier compte sera Gérant/Fondation.
    const totalUsers = dbStore.getUsers().length;
    const userRole: StaffRole = totalUsers === 0 ? 'fondation' : 'user';

    const user = dbStore.getOrCreateUser(discordUser.id, username, avatarUrl);
    if (totalUsers === 0) {
      dbStore.promoteUser(user.id, 'fondation', 'System', 'Initialisation');
    }

    // Créer une session
    const token = 'discord_session_' + Math.random().toString(36).substring(2) + Date.now();
    SESSIONS[token] = { userId: user.id };

    // Notification Webhook Discord sur connexion officielle OAuth2
    await sendDiscordWebhook({
      title: '🔐 Authentification Discord OAuth2 Réussie',
      description: `Une authentification officielle sécurisée a été validée via la passerelle Discord.`,
      color: 0x5865F2, // Discord Blurple
      fields: [
        { name: 'Pseudo Discord', value: `**${user.username}**`, inline: true },
        { name: 'ID Discord Snowflake', value: `\`${user.id}\``, inline: true },
        { name: 'Grade Autorisé', value: `\`${user.role.toUpperCase()}\``, inline: true }
      ],
      thumbnail: user.avatar ? { url: user.avatar } : undefined,
    });

    res.setHeader('Set-Cookie', `staff_candidacy_session=${token}; Path=/; HttpOnly; SameSite=None; Secure; Max-Age=2592000`);
    
    // Renvoyer une page HTML capable de poster un message au parent (popup) ou de rediriger
    res.send(`
      <html>
        <head>
          <title>Authentification réussie</title>
          <style>
            body {
              background: #090d16;
              color: #f1f5f9;
              font-family: system-ui, -apple-system, sans-serif;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100vh;
              margin: 0;
              text-align: center;
            }
            .card {
              background: rgba(255, 255, 255, 0.03);
              backdrop-filter: blur(12px);
              padding: 2.5rem;
              border-radius: 1.25rem;
              border: 1px solid rgba(255,255,255,0.08);
              box-shadow: 0 20px 40px rgba(0,0,0,0.5);
              max-width: 320px;
            }
            h1 { font-size: 1.35rem; font-weight: 800; margin-bottom: 0.75rem; color: #10b981; uppercase; letter-spacing: 0.025em; }
            p { font-size: 0.85rem; color: #94a3b8; line-height: 1.5; }
            .spinner {
              width: 28px;
              height: 28px;
              border: 2px solid rgba(255,255,255,0.1);
              border-top-color: #10b981;
              border-radius: 50%;
              animation: spin 0.8s linear infinite;
              margin: 1.5rem auto 0;
            }
            @keyframes spin { to { transform: rotate(360deg); } }
          </style>
        </head>
        <body>
          <div class="card">
            <h1>Connexion Établie !</h1>
            <p>Authentification réussie. Votre session Amsterdam RP est désormais active.</p>
            <div class="spinner"></div>
          </div>
          <script>
            try {
              if (window.opener) {
                window.opener.postMessage({ type: 'OAUTH_AUTH_SUCCESS' }, '*');
                window.close();
              } else {
                window.location.href = '/';
              }
            } catch (err) {
              window.location.href = '/';
            }
          </script>
        </body>
      </html>
    `);
  } catch (error) {
    console.error('Erreur Authentification Discord:', error);
    res.status(500).send(`Erreur lors de la connexion Discord: ${error instanceof Error ? error.message : String(error)}`);
  }
});

// Obtenir ses candidatures (Espace Candidat)
app.get('/api/applications/my', requireAuth, (req, res) => {
  const user = (req as any).user;
  const list = dbStore.getApplicationsForUser(user.id);
  res.json({ success: true, applications: list });
});

// Soumettre une candidature
app.post('/api/applications', requireAuth, async (req, res) => {
  const user = (req as any).user;
  const {
    pseudoRoblox,
    pseudoDiscord,
    age,
    fuseauHoraire,
    disponibilites,
    experienceStaff,
    connaissanceCommandes,
    significationHrp,
    pourquoiRejoindre,
    comportementPerturbateur,
    comportementInapproprieMpj,
    luReglement
  } = req.body;

  if (!pseudoRoblox || !pseudoDiscord || !age || luReglement === undefined) {
    res.status(400).json({ error: 'Les questions obligatoires (Pseudo Roblox, Pseudo Discord, Âge, Règlement) doivent être complétées.' });
    return;
  }

  if (!luReglement) {
    res.status(400).json({ error: 'Vous devez lire et accepter le règlement pour soumettre votre candidature.' });
    return;
  }

  const ageNum = parseInt(age);
  if (isNaN(ageNum) || ageNum < 12 || ageNum > 99) {
    res.status(400).json({ error: 'Veuillez saisir un âge valide (12-99 ans).' });
    return;
  }

  const app = dbStore.createApplication(user.id, {
    pseudoRoblox,
    pseudoDiscord,
    age: ageNum,
    fuseauHoraire: fuseauHoraire || 'Non spécifié',
    disponibilites: Array.isArray(disponibilites) ? disponibilites : [],
    experienceStaff: experienceStaff || 'Aucune',
    connaissanceCommandes: connaissanceCommandes || 'Aucune',
    significationHrp: significationHrp || 'Aucune',
    pourquoiRejoindre: pourquoiRejoindre || 'Aucune',
    comportementPerturbateur: comportementPerturbateur || 'Aucune',
    comportementInapproprieMpj: comportementInapproprieMpj || 'Aucune',
    luReglement: !!luReglement
  });

  // Diffusion temps réel
  broadcastRealtimeEvent('application_created', { id: app.id, username: user.username });

  // Envoyer une notification Webhook Discord (Embed VIP)
  const daysText = Array.isArray(disponibilites) && disponibilites.length > 0 ? disponibilites.join(', ') : 'Aucun jour sélectionné';
  await sendDiscordWebhook({
    title: '📥 Nouvelle Candidature Staff !',
    description: `Un joueur vient de soumettre une candidature sur la plateforme de recrutement d'Amsterdam RP.`,
    color: 0x5865F2, // Discord Blurple
    fields: [
      { name: '1. Pseudo Roblox', value: `**${pseudoRoblox}**`, inline: true },
      { name: '2. Pseudo Discord', value: `**${pseudoDiscord}**`, inline: true },
      { name: '3. Âge', value: `${ageNum} ans`, inline: true },
      { name: '4. Fuseau horaire', value: fuseauHoraire || 'Non spécifié', inline: true },
      { name: '5. Disponibilités', value: daysText, inline: true },
      { name: '6. Expérience', value: experienceStaff && experienceStaff.length > 150 ? `${experienceStaff.substring(0, 147)}...` : experienceStaff || 'Aucune', inline: false },
      { name: 'Lien d\'accès au Panel', value: `[Accéder au Panel Administration](${process.env.APP_URL || 'http://localhost:3000'})` }
    ],
    thumbnail: user.avatar ? { url: user.avatar } : undefined,
    timestamp: new Date().toISOString()
  });

  res.json({ success: true, application: app });
});

// Récupérer les candidatures (Espace Staff - Filtrage selon rôle)
// Modérateur : Voit uniquement les candidatures 'pending' (En attente).
// Admin, Gérant, Fondation : Voient tout.
app.get('/api/applications', requireAuth, requireRole(['modo', 'admin', 'gerant', 'fondation']), (req, res) => {
  const user = (req as any).user;
  const allApps = dbStore.getApplications();

  if (user.role === 'modo') {
    // Les modérateurs n'ont accès qu'aux candidatures en attente de traitement
    const filtered = allApps.filter(app => app.status === 'pending');
    res.json({ success: true, applications: filtered });
    return;
  }

  // Admin, Gérant et Fondation voient absolument toutes les candidatures
  res.json({ success: true, applications: allApps });
});

// Modifier le statut d'une candidature (Admin ou supérieur)
app.patch('/api/applications/:id/status', requireAuth, requireRole(['admin', 'gerant', 'fondation']), async (req, res) => {
  const staff = (req as any).user;
  const appId = req.params.id;
  const { status } = req.body;

  const validStatuses: ApplicationStatus[] = ['pending', 'reading', 'accepted', 'rejected'];
  if (!validStatuses.includes(status)) {
    res.status(400).json({ error: 'Statut de candidature invalide.' });
    return;
  }

  const result = dbStore.updateApplicationStatus(appId, status, staff.id, staff.username);
  if (!result.success || !result.application) {
    res.status(404).json({ error: 'Candidature introuvable.' });
    return;
  }

  const app = result.application;

  // Diffusion temps réel
  broadcastRealtimeEvent('application_status_updated', { id: appId, status, username: app.username, staff: staff.username });

  // Notification Webhook Discord
  const statusLabels: Record<ApplicationStatus, string> = {
    pending: 'En attente ⏳',
    reading: 'En cours de lecture 📖',
    accepted: 'Acceptée ✅',
    rejected: 'Refusée ❌'
  };

  const colors: Record<ApplicationStatus, number> = {
    pending: 0xFEE75C, // Yellow
    reading: 0x3498DB, // Blue
    accepted: 0x57F287, // Green
    rejected: 0xED4245 // Red
  };

  await sendDiscordWebhook({
    title: '⚙️ Mise à jour de Candidature',
    description: `La candidature de **${app.username}** a été mise à jour par le staff.`,
    color: colors[status],
    fields: [
      { name: 'Candidat', value: `${app.username} (ID Discord: \`${app.userId}\`)`, inline: true },
      { name: 'Modérateur / Staff', value: `${staff.username}`, inline: true },
      { name: 'Nouveau Statut', value: `**${statusLabels[status]}**`, inline: false },
      { name: 'Lien du Panel', value: `[Ouvrir le Panel Admin](${process.env.APP_URL || 'http://localhost:3000'})` }
    ],
    thumbnail: app.avatar ? { url: app.avatar } : undefined,
    timestamp: new Date().toISOString()
  });

  res.json({ success: true, application: app });
});

// Ajouter un commentaire interne (Gérant ou supérieur)
app.post('/api/applications/:id/comments', requireAuth, requireRole(['gerant', 'fondation']), (req, res) => {
  const staff = (req as any).user;
  const appId = req.params.id;
  const { content } = req.body;

  if (!content || content.trim().length === 0) {
    res.status(400).json({ error: 'Le commentaire ne peut pas être vide.' });
    return;
  }

  const result = dbStore.addComment(appId, staff.id, staff.username, content);
  if (!result.success) {
    res.status(404).json({ error: 'Candidature introuvable.' });
    return;
  }

  // Diffusion temps réel
  broadcastRealtimeEvent('comment_added', { id: appId, author: staff.username });

  res.json({ success: true, comment: result.comment });
});

// Livre d'or / Shoutbox interactif temps réel
app.post('/api/realtime/message', requireAuth, (req, res) => {
  const { message } = req.body;
  const user = (req as any).user;
  if (!message || message.trim() === '') {
    res.status(400).json({ error: 'Message vide.' });
    return;
  }
  
  broadcastRealtimeEvent('user_message', {
    id: 'msg_' + Date.now() + Math.random().toString(36).substring(2),
    username: user.username,
    avatar: user.avatar,
    message: message.trim(),
    role: user.role
  });
  
  res.json({ success: true });
});

// Obtenir la liste complète des utilisateurs (Fondation - pour gérer le staff)
app.get('/api/users', requireAuth, requireRole(['fondation']), (req, res) => {
  const users = dbStore.getUsers();
  const activeUserIds = new Set(Object.values(SESSIONS).map(s => s.userId));
  
  const usersWithOnlineStatus = users.map(user => {
    const isSelf = user.id === (req as any).user.id;
    // On simule l'activité du Fondateur Thomas_Giga et de Sarah_Admin pour animer le tableau
    const isMockOnline = user.id === '111111111111111111' || user.id === '333333333333333333';
    
    return {
      ...user,
      isOnline: isSelf || activeUserIds.has(user.id) || isMockOnline
    };
  });
  
  res.json({ success: true, users: usersWithOnlineStatus });
});

// Promouvoir un membre Discord au Staff (Fondation uniquement)
app.post('/api/staff/promote', requireAuth, requireRole(['fondation']), async (req, res) => {
  const staff = (req as any).user;
  const { userId, role } = req.body;

  const validRoles: StaffRole[] = ['modo', 'admin', 'gerant', 'fondation'];
  if (!userId || !role || !validRoles.includes(role)) {
    res.status(400).json({ error: 'ID utilisateur valide et rôle staff requis.' });
    return;
  }

  const result = dbStore.promoteUser(userId, role, staff.id, staff.username);
  if (!result.success || !result.user) {
    // Si l'utilisateur n'existe pas en base mais qu'on a son ID, on peut le pré-créer
    // pour faciliter l'assignation de rôles directs de membres externes !
    const preCreatedUser = dbStore.getOrCreateUser(userId, `Utilisateur_Discord_${userId.substring(0,4)}`, null);
    const finalResult = dbStore.promoteUser(preCreatedUser.id, role, staff.id, staff.username);
    
    if (!finalResult.success || !finalResult.user) {
      res.status(404).json({ error: 'Impossible de promouvoir l\'utilisateur.' });
      return;
    }
    
    // Diffusion temps réel
    broadcastRealtimeEvent('staff_promoted', { user: finalResult.user, role, staff: staff.username });
    await notifyStaffChange(finalResult.user, role, staff.username);
    res.json({ success: true, user: finalResult.user });
    return;
  }

  // Diffusion temps réel
  broadcastRealtimeEvent('staff_promoted', { user: result.user, role, staff: staff.username });
  await notifyStaffChange(result.user, role, staff.username);
  res.json({ success: true, user: result.user });
});

// Révoquer un membre du staff (Fondation uniquement)
app.post('/api/staff/revoke', requireAuth, requireRole(['fondation']), async (req, res) => {
  const staff = (req as any).user;
  const { userId } = req.body;

  if (!userId) {
    res.status(400).json({ error: 'ID utilisateur requis.' });
    return;
  }

  const targetUser = dbStore.getUser(userId);
  if (!targetUser) {
    res.status(404).json({ error: 'Utilisateur introuvable.' });
    return;
  }

  const oldRole = targetUser.role;
  const result = dbStore.revokeUser(userId, staff.id, staff.username);
  if (!result.success || !result.user) {
    res.status(500).json({ error: 'Une erreur est survenue lors de la révocation.' });
    return;
  }

  // Diffusion temps réel
  broadcastRealtimeEvent('staff_revoked', { username: targetUser.username, staff: staff.username });

  // Webhook notification
  await sendDiscordWebhook({
    title: '🚨 Révocation d\'accès Staff !',
    description: `Un membre du staff a été **destitué** de ses fonctions de modération par la Fondation.`,
    color: 0xED4245, // Red
    fields: [
      { name: 'Ancien Staff', value: `**${targetUser.username}** (ID Discord : \`${userId}\`)`, inline: true },
      { name: 'Retiré par', value: `${staff.username}`, inline: true },
      { name: 'Rôle révoqué', value: `\`${oldRole.toUpperCase()}\``, inline: false },
      { name: 'Statut du compte', value: 'Retour au statut de simple candidat / utilisateur', inline: false }
    ],
    timestamp: new Date().toISOString()
  });

  res.json({ success: true, user: result.user });
});

// Helper webhook de promotion
async function notifyStaffChange(user: any, newRole: StaffRole, authorName: string) {
  await sendDiscordWebhook({
    title: '👑 Promotion au Staff RP !',
    description: `La hiérarchie présente une promotion importante du staff.`,
    color: 0xFEE75C, // Yellow/Gold
    fields: [
      { name: 'Promu', value: `**${user.username}** (ID Discord : \`${user.id}\`)`, inline: true },
      { name: 'Validé par', value: `${authorName}`, inline: true },
      { name: 'Nouveau Rôle', value: `\`${newRole.toUpperCase()}\``, inline: false }
    ],
    thumbnail: user.avatar ? { url: user.avatar } : undefined,
    timestamp: new Date().toISOString()
  });
}

// Obtenir les journaux de modération (Fondation uniquement)
app.get('/api/logs', requireAuth, requireRole(['fondation']), (req, res) => {
  res.json({ success: true, logs: dbStore.getLogs() });
});

// Obtenir les statistiques du panel (Gérant ou supérieur)
app.get('/api/stats', requireAuth, requireRole(['gerant', 'fondation']), (req, res) => {
  const users = dbStore.getUsers();
  const apps = dbStore.getApplications();

  const stats = {
    total: apps.length,
    pending: apps.filter(a => a.status === 'pending').length,
    reading: apps.filter(a => a.status === 'reading').length,
    accepted: apps.filter(a => a.status === 'accepted').length,
    rejected: apps.filter(a => a.status === 'rejected').length,
    modoCount: users.filter(u => u.role === 'modo').length,
    adminCount: users.filter(u => u.role === 'admin').length,
    gerantCount: users.filter(u => u.role === 'gerant').length,
    fondationCount: users.filter(u => u.role === 'fondation').length,
  };

  res.json({ success: true, stats });
});

// Config status for UI
app.get('/api/debug/config', (req, res) => {
  res.json({
    discordClientIdConfigured: !!process.env.DISCORD_CLIENT_ID,
    discordWebhookConfigured: !!process.env.DISCORD_WEBHOOK_URL,
    appUrl: process.env.APP_URL || 'Non défini',
  });
});

// ==========================================
// VITE DEV & PRODUCTION SERVING
// ==========================================

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // En développement, monter le serveur de dev Vite
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Middlewares Vite chargés en mode développement.");
  } else {
    // En production, servir l'application compilée
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log("Fichiers statiques dist configurés pour le mode production.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`\n======================================================`);
    console.log(`🚀 SERVEUR DE RECRUTEMENT ROBLOX EMERGENCY HAMBURG EN COURS D'EXÉCUTION`);
    console.log(`👉 URL Locale : http://localhost:${PORT}`);
    console.log(`======================================================\n`);
  });
}

startServer();
