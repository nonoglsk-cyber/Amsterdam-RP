import React, { useState, useEffect } from 'react';
import { User, Application, ModerationLog, StaffRole, DashboardStats } from './types';
import LoginForm from './components/LoginForm';
import CandidatePanel from './components/CandidatePanel';
import StaffApplications from './components/StaffApplications';
import StaffManagement from './components/StaffManagement';
import AuditLogs from './components/AuditLogs';
import LiveHub from './components/LiveHub';

import {
  Crown,
  ShieldAlert,
  Users,
  LogOut,
  RefreshCw,
  FileText,
  Terminal,
  Columns,
  Sparkles,
  Award,
  AlertCircle,
  Radio,
  Bell,
  Cpu
} from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loginMode, setLoginMode] = useState<'candidate' | 'staff' | null>(null);
  const [applications, setApplications] = useState<Application[]>([]);
  const [usersList, setUsersList] = useState<User[]>([]);
  const [moderationLogs, setModerationLogs] = useState<ModerationLog[]>([]);
  const [dashboardStats, setDashboardStats] = useState<DashboardStats | null>(null);

  const [loading, setLoading] = useState<boolean>(true);
  const [refreshing, setRefreshing] = useState<boolean>(false);
  const [debugConfig, setDebugConfig] = useState<{
    discordClientIdConfigured: boolean;
    discordWebhookConfigured: boolean;
    appUrl: string;
  } | null>(null);

  // Vue active de l'onglet
  const [activeTab, setActiveTab] = useState<string>('live-hub');

  // Real-time Event variables
  const [liveMessages, setLiveMessages] = useState<any[]>([
    { id: '1', username: 'Thomas_Giga', avatar: 'https://images.unsplash.com/photo-1566492031773-4f4e44671857?auto=format&fit=crop&w=150&h=150', message: 'Bienvenue sur la plateforme de recrutement Amsterdam RP ! N’hésitez pas à poster votre candidature ! 🇳🇱', role: 'fondation', timestamp: '12:00' },
    { id: '2', username: 'Sarah_Admin', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150', message: 'Félicitations aux admis de la session d’hier. Les candidatures du jour sont en cours de traitement. ⏳', role: 'admin', timestamp: '12:15' },
  ]);
  const [recentEvents, setRecentEvents] = useState<any[]>([
    { id: 'ev1', text: '📡 Liaison EventStream Amsterdam RP établie.', time: 'Maintenant', type: 'system' }
  ]);

  // Connection sequence states
  const [connectionStep, setConnectionStep] = useState<number>(-1);
  const [targetUserToConnect, setTargetUserToConnect] = useState<User | null>(null);
  const [connectionProgress, setConnectionProgress] = useState<number>(0);

  // Notifications toasts
  const [notifications, setNotifications] = useState<{ id: string; text: string; type: 'success' | 'info' | 'warning' | 'reward' }[]>([]);
  const showNotification = (text: string, type: 'success' | 'info' | 'warning' | 'reward') => {
    const id = Math.random().toString(36).substring(2);
    setNotifications(prev => [...prev, { id, text, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  // Charger les données d'authentification initiales
  const checkAuth = async () => {
    try {
      const response = await fetch('/api/auth/me');
      const data = await response.json();
      if (data.user) {
        setCurrentUser(data.user);
      } else {
        setCurrentUser(null);
      }
    } catch (e) {
      console.error('Erreur authentification:', e);
    } finally {
      setLoading(false);
    }
  };

  // Charger débogage configuration serveur
  const fetchDebugConfig = async () => {
    try {
      const response = await fetch('/api/debug/config');
      if (response.ok) {
        const data = await response.json();
        setDebugConfig(data);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Synchronisation générale des données selon le rôle de l'utilisateur actif
  const loadDomainData = async () => {
    if (!currentUser) return;
    setRefreshing(true);
    try {
      // 1. Charger les candidatures
      if (currentUser.role === 'user') {
        // Un candidat normal ne charge que ses propres candidatures
        const response = await fetch('/api/applications/my');
        if (response.ok) {
          const data = await response.json();
          setApplications(data.applications || []);
        }
      } else {
        // Les staffs chargent toutes les candidatures qu'ils ont le droit de voir
        const response = await fetch('/api/applications');
        if (response.ok) {
          const data = await response.json();
          setApplications(data.applications || []);
        }
      }

      // 2. Charger les statistiques (Gérant +)
      if (currentUser.role === 'gerant' || currentUser.role === 'fondation') {
        const statsResponse = await fetch('/api/stats');
        if (statsResponse.ok) {
          const sData = await statsResponse.json();
          setDashboardStats(sData.stats);
        }
      }

      // 3. Charger la liste des membres & logs d'audit (Fondation uniquement)
      if (currentUser.role === 'fondation') {
        const [usersRes, logsRes] = await Promise.all([
          fetch('/api/users'),
          fetch('/api/logs')
        ]);

        if (usersRes.ok) {
          const uData = await usersRes.json();
          setUsersList(uData.users || []);
        }

        if (logsRes.ok) {
          const lData = await logsRes.json();
          setModerationLogs(lData.logs || []);
        }
      }
    } catch (e) {
      console.error('Erreur lors du chargement des données:', e);
    } finally {
      setRefreshing(false);
    }
  };

  const handleOauthSuccess = async () => {
    try {
      const response = await fetch('/api/auth/me');
      if (response.ok) {
        const data = await response.json();
        if (data.user) {
          setTargetUserToConnect(data.user);
          setConnectionProgress(0);
          setConnectionStep(0);
        }
      }
    } catch (e) {
      console.error('Erreur de rapatriement après connexion OAuth:', e);
    }
  };

  useEffect(() => {
    checkAuth();
    fetchDebugConfig();

    const handleOauthMessage = (event: MessageEvent) => {
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost') && !origin.includes('127.0.0.1')) {
        return;
      }
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        handleOauthSuccess();
      }
    };

    window.addEventListener('message', handleOauthMessage);
    return () => window.removeEventListener('message', handleOauthMessage);
  }, []);

  useEffect(() => {
    if (currentUser) {
      loadDomainData();
      // Rediriger intelligemment vers le Live Hub
      setActiveTab('live-hub');
    } else {
      setApplications([]);
      setUsersList([]);
      setModerationLogs([]);
      setDashboardStats(null);
    }
  }, [currentUser]);

  // Synchronisation par EventSource (flux SSE en temps réel)
  useEffect(() => {
    if (!currentUser) return;

    const eventSource = new EventSource('/api/realtime/stream');

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        console.log("Événement temps réel reçu:", data);

        if (data.type === 'welcome') {
          return;
        }

        // Mettre à jour les données
        loadDomainData();

        // Récupérer l'heure
        const nowStr = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });

        if (data.type === 'user_message') {
          const newMsg = {
            id: data.id,
            username: data.username,
            avatar: data.avatar,
            message: data.message,
            role: data.role,
            timestamp: nowStr
          };
          setLiveMessages(prev => [newMsg, ...prev.slice(0, 19)]);
          if (data.username !== currentUser.username) {
            showNotification(`💬 ${data.username} : "${data.message.substring(0, 30)}..."`, 'info');
          }
        } else if (data.type === 'application_created') {
          showNotification(`📥 Nouvelle candidature par ${data.username} !`, 'info');
          setRecentEvents(prev => [{
            id: 'ev_' + Date.now(),
            text: `📥 Candidature créée par ${data.username}`,
            time: nowStr,
            type: 'created'
          }, ...prev.slice(0, 14)]);
        } else if (data.type === 'application_status_updated') {
          const statusLabels: Record<string, string> = {
            pending: 'En attente ⏳',
            reading: 'En examen 📖',
            accepted: 'Acceptée ✅',
            rejected: 'Refusée ❌'
          };
          showNotification(`⚙️ Candidature de ${data.username} mise à jour : ${statusLabels[data.status]} !`, 'success');
          setRecentEvents(prev => [{
            id: 'ev_' + Date.now(),
            text: `⚙️ Dossier de ${data.username} passé à: ${statusLabels[data.status]} par ${data.staff}`,
            time: nowStr,
            type: 'status'
          }, ...prev.slice(0, 14)]);
        } else if (data.type === 'comment_added') {
          showNotification(`💬 Avis secret rédigé par ${data.author}`, 'info');
          setRecentEvents(prev => [{
            id: 'ev_' + Date.now(),
            text: `💬 Avis de l'officier ${data.author} déposé`,
            time: nowStr,
            type: 'comment'
          }, ...prev.slice(0, 14)]);
        } else if (data.type === 'staff_promoted') {
          showNotification(`👑 Promotion: ${data.user?.username} est promu ${data.role.toUpperCase()} !`, 'reward');
          setRecentEvents(prev => [{
            id: 'ev_' + Date.now(),
            text: `👑 ${data.user?.username} élevé au grade ${data.role.toUpperCase()} par ${data.staff}`,
            time: nowStr,
            type: 'promoted'
          }, ...prev.slice(0, 14)]);
        } else if (data.type === 'staff_revoked') {
          showNotification(`🚨 Révocation : ${data.username} démissionné ou destitué.`, 'warning');
          setRecentEvents(prev => [{
            id: 'ev_' + Date.now(),
            text: `🚨 Révocation administrative pour ${data.username} par ${data.staff}`,
            time: nowStr,
            type: 'revoked'
          }, ...prev.slice(0, 14)]);
        }
      } catch (err) {
        console.error("Erreur parsing EventSource", err);
      }
    };

    eventSource.onerror = (err) => {
      console.log("Déconnexion temporaire du flux temps réel. Tentative de reconnexion...", err);
      eventSource.close();
    };

    return () => {
      eventSource.close();
    };
  }, [currentUser]);

  // Chronomètre de connexion immersive
  useEffect(() => {
    if (connectionStep === -1 || !targetUserToConnect) return;

    const interval = setInterval(() => {
      setConnectionProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setCurrentUser(targetUserToConnect);
            setConnectionStep(-1);
            setTargetUserToConnect(null);
            showNotification(`📡 Session sécurisée EventStream active pour ${targetUserToConnect.username}`, 'success');
          }, 350);
          return 100;
        }

        const nextProg = p + 4;
        const currentStep = Math.min(3, Math.floor(nextProg / 25));
        if (currentStep !== connectionStep) {
          setConnectionStep(currentStep);
        }

        return nextProg;
      });
    }, 60);

    return () => clearInterval(interval);
  }, [connectionStep, targetUserToConnect]);

  const handleLogout = async () => {
    try {
      const resp = await fetch('/api/auth/logout', { method: 'POST' });
      if (resp.ok) {
        setCurrentUser(null);
        setActiveTab('live-hub');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleLoginSimulated = (user: User) => {
    setTargetUserToConnect(user);
    setConnectionProgress(0);
    setConnectionStep(0);
  };

  const handleSendLiveMessage = async (msg: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/realtime/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg })
      });
      return response.ok;
    } catch (e) {
      console.error(e);
      return false;
    }
  };

  const handleDiscordLogin = () => {
    const width = 600;
    const height = 750;
    const left = window.screen.width / 2 - width / 2;
    const top = window.screen.height / 2 - height / 2;
    
    const popup = window.open(
      '/api/auth/discord/initiate',
      'discord_oauth_popup',
      `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`
    );
    
    if (!popup) {
      showNotification("S'il vous plaît, désactivez le bloqueur de popups de votre navigateur pour lier votre compte Discord.", 'warning');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-100 font-sans" id="app-loading-screen">
        <div className="flex flex-col items-center gap-4">
          <RefreshCw className="w-8 h-8 text-indigo-500 animate-spin" />
          <p className="text-sm font-semibold tracking-wider font-display uppercase text-slate-400">Chargement de la plateforme...</p>
        </div>
      </div>
    );
  }

  const roleLabels: Record<StaffRole, { text: string; css: string }> = {
    user: { text: 'Candidat Mandataire', css: 'bg-slate-800 text-slate-300 border-slate-700' },
    modo: { text: 'Modérateur', css: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20' },
    admin: { text: 'Administrateur', css: 'bg-rose-500/10 text-rose-400 border-rose-500/20' },
    gerant: { text: 'Gérant Staff', css: 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' },
    fondation: { text: 'Fondation / Owner', css: 'bg-amber-500/15 text-amber-400 border-amber-500/20' }
  };

  const activeRoleBadge = currentUser ? roleLabels[currentUser.role] : null;

  return (
    <div className="min-h-screen mesh-gradient font-sans text-slate-200 relative" id="main-application-root">
      
      {/* Immersive real-time simulated connection sequence overlay */}
      {connectionStep >= 0 && (
        <div className="fixed inset-0 z-50 bg-slate-950/96 backdrop-blur-md flex flex-col items-center justify-center font-mono text-slate-200 p-6 select-none animate-fade-in" id="connect-overlay">
          <div className="max-w-md w-full p-8 border border-white/10 rounded-2xl bg-black/45 shadow-2xl relative text-center space-y-6">
            <div className="absolute top-2 right-4 text-[9px] text-pink-400 tracking-widest font-bold uppercase animate-pulse">SSE Gateway active</div>
            
            <div className="relative w-20 h-20 mx-auto flex items-center justify-center">
              <span className="animate-ping absolute inline-flex h-16 w-16 rounded-full bg-pink-500/10 opacity-75"></span>
              <div className="w-16 h-16 rounded-full border-2 border-indigo-500/20 border-t-pink-500 border-b-violet-500 animate-spin flex items-center justify-center">
                <Cpu className="w-6 h-6 text-pink-400" />
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-display font-black text-slate-100 text-sm tracking-wide uppercase">Établissement du Flux Temps Réel</h3>
              <p className="text-[10px] text-slate-400">Amsterdam RP Secure Gateway Link</p>
            </div>

            <div className="p-4 bg-black/40 border border-white/5 rounded-xl text-left text-[11px] font-mono leading-relaxed space-y-1 text-indigo-300">
              <div className="flex justify-between">
                <span>📡 Connexion REST Gateway...</span>
                <span className="text-emerald-405 font-bold text-emerald-400">PRÊT</span>
              </div>
              <div className="flex justify-between">
                <span>🔐 Authentification Secure Token...</span>
                <span className={connectionStep >= 1 ? "text-emerald-405 font-bold text-emerald-400" : "text-pink-400 animate-pulse"}>
                  {connectionStep >= 1 ? "OK" : "EN COURS"}
                </span>
              </div>
              <div className="flex justify-between">
                <span>⚙️ Permis de sécurité & rôles...</span>
                <span className={connectionStep >= 2 ? "text-emerald-405 font-bold text-emerald-400" : connectionStep === 1 ? "text-pink-400 animate-pulse" : "text-slate-600"}>
                  {connectionStep >= 2 ? "AUTORISÉ" : connectionStep === 1 ? "VÉRIFICATION" : "ATTENTE"}
                </span>
              </div>
              <div className="flex justify-between">
                <span>⚡ Montage EventStream SSE...</span>
                <span className={connectionStep >= 3 ? "text-emerald-450 font-bold text-emerald-400" : connectionStep === 2 ? "text-pink-400 animate-pulse" : "text-slate-600"}>
                  {connectionStep >= 3 ? "SYNCHRO" : connectionStep === 2 ? "CONSTITUTION" : "ATTENTE"}
                </span>
              </div>
            </div>

            {/* Custom progress loading bar */}
            <div className="space-y-1.5 text-xs text-slate-400">
              <div className="flex justify-between text-[10px] font-semibold">
                <span>TUNNEL DISCORD SYNCHRONISÉ:</span>
                <span className="font-bold text-pink-400">{connectionProgress}%</span>
              </div>
              <div className="w-full h-1.5 bg-black/50 rounded-full overflow-hidden border border-white/5 p-[1px]">
                <div className="h-full bg-gradient-to-r from-pink-500 via-indigo-500 to-violet-500 rounded-full transition-all duration-75" style={{ width: `${connectionProgress}%` }}></div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating active real-time toast notifications */}
      <div className="fixed top-20 right-4 z-50 space-y-2 pointer-events-none max-w-sm w-full" id="toast-notifications-container">
        {notifications.map(n => {
          let styleClass = "border-white/10 bg-black/85 text-slate-200";
          if (n.type === 'success') styleClass = "border-emerald-500/30 bg-emerald-950/90 text-emerald-200 shadow-lg shadow-emerald-900/10";
          if (n.type === 'warning') styleClass = "border-rose-500/30 bg-rose-950/90 text-rose-250 shadow-lg shadow-rose-900/10";
          if (n.type === 'reward') styleClass = "border-amber-500/30 bg-amber-950/90 text-amber-250 shadow-lg shadow-amber-950/10";

          return (
            <div
              key={n.id}
              className={`p-3 rounded-xl border backdrop-blur shadow-2xl text-xs font-semibold flex items-center justify-between gap-2.5 pointer-events-auto select-none animate-fade-in ${styleClass}`}
              id={`toast-${n.id}`}
            >
              <div className="grow">{n.text}</div>
              <button
                onClick={() => setNotifications(prev => prev.filter(x => x.id !== n.id))}
                className="hover:text-white text-slate-400 transition pl-1 shrink-0 p-1 rounded-md"
              >
                ✕
              </button>
            </div>
          );
        })}
      </div>

      {/* 1. Header principal */}
      <header className="sticky top-0 z-40 bg-black/20 backdrop-blur-md border-b border-white/10 px-6 py-3" id="main-header">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-tr from-pink-600 to-red-650 rounded-lg text-white font-display font-black flex items-center gap-0.5 justify-center shrink-0 shadow-lg shadow-pink-600/20 px-2.5">
              <span>A</span>
              <span className="text-red-300">M</span>
              <span>S</span>
            </div>
            <div>
              <h1 className="font-display font-extrabold text-base tracking-wide text-slate-100 flex items-center gap-2 uppercase">
                <span>Amsterdam RP</span>
                <span className="text-[10px] bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 border border-emerald-500/20 rounded uppercase font-mono font-bold tracking-tight animate-pulse flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                  <span>Live EventStream Link</span>
                </span>
              </h1>
              <p className="text-[10px] text-slate-400 font-medium">Portail Officiel d'Admission & Recrutement de l'Équipe Staff - Amsterdam RP</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {currentUser ? (
              <div className="flex items-center gap-3.5 bg-white/5 backdrop-blur border border-white/10 rounded-xl p-1.5 pl-3" id="profile-indicator">
                <div className="text-right">
                  <div className="text-xs font-bold text-slate-200">{currentUser.username}</div>
                  <div className="flex items-center gap-1.5 justify-end mt-0.5">
                    <span className={`text-[9px] font-bold px-1.5 border leading-none py-0.5 rounded ${activeRoleBadge?.css}`}>
                      {activeRoleBadge?.text}
                    </span>
                  </div>
                </div>

                <img
                  src={currentUser.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150'}
                  alt={currentUser.username}
                  className="w-10 h-10 rounded-lg border border-white/15 shrink-0 pointer-events-none select-none"
                  referrerPolicy="no-referrer"
                />

                <button
                  onClick={handleLogout}
                  className="p-2 bg-white/5 border border-white/10 hover:bg-white/15 hover:text-white text-slate-300 rounded-lg transition duration-205 cursor-pointer"
                  title="Déconnexion"
                  id="btn-logout"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="text-xs text-slate-400 font-medium bg-black/10 px-3 py-1.5 border border-white/5 rounded-lg backdrop-blur-sm">Amsterdam RP • Emergency Hamburg</div>
            )}
          </div>
        </div>
      </header>

      {/* 2. Container central */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-6" id="main-content-flow">
        
        {/* 3. Vue invité hors-ligne ou formulaire d'authentification */}
        {!currentUser ? (
          loginMode ? (
            <LoginForm 
              mode={loginMode}
              onLoginSimulated={handleLoginSimulated} 
              debugConfig={debugConfig} 
              onDiscordLogin={handleDiscordLogin} 
              onBack={() => setLoginMode(null)}
            />
          ) : (
            <div className="max-w-4xl mx-auto space-y-8 animate-fade-in" id="guest-landing-portal">
              {/* Grand Hero Section */}
              <div className="glass rounded-3xl p-8 md:p-12 text-center relative overflow-hidden border border-white/10" id="hero-portal-card">
                <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-tr from-pink-500/5 via-transparent to-indigo-500/5 -z-10"></div>
                <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-pink-500/10 to-transparent blur-3xl rounded-full"></div>
                <div className="absolute -bottom-10 -left-10 w-96 h-96 bg-gradient-to-tr from-indigo-500/10 to-transparent blur-3xl rounded-full"></div>

                <div className="inline-flex p-4 bg-pink-500/10 border border-pink-500/20 text-pink-400 rounded-2xl mb-6 shadow-md shadow-pink-500/5">
                  <Radio className="w-10 h-10 text-pink-400 animate-pulse" />
                </div>

                <h1 className="font-display font-black text-3xl md:text-4xl text-slate-100 tracking-tight leading-tight uppercase max-w-2xl mx-auto">
                  Cabinet d'Admission & Recrutement Staff
                </h1>
                <p className="text-sm text-slate-400 leading-relaxed max-w-xl mx-auto mt-4">
                  Devenez acteur de la modération sur le serveur référence <strong className="text-pink-400">Emergency Hamburg d'Amsterdam RP (Roblox)</strong>. Proposez votre candidature et suivez son avancement en direct grâce à notre infrastructure connectée.
                </p>

                {/* Bouton Connexion en tant que Staff et Postuler */}
                <div className="flex flex-col sm:flex-row gap-4 items-center justify-center mt-10">
                  <button
                    onClick={() => setLoginMode('candidate')}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 bg-gradient-to-r from-pink-600 to-indigo-650 hover:from-pink-500 hover:to-indigo-500 text-slate-100 font-extrabold text-sm tracking-wider uppercase rounded-xl cursor-pointer transition shadow-xl hover:-translate-y-0.5 active:translate-y-0"
                    id="btn-apply-portal"
                  >
                    <span>Déposer ma candidature</span>
                    <Sparkles className="w-4 h-4 shrink-0 text-yellow-300 animate-pulse" />
                  </button>

                  <button
                    onClick={() => setLoginMode('staff')}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 bg-white/5 hover:bg-white/10 text-slate-200 hover:text-white font-extrabold text-sm tracking-wider uppercase rounded-xl cursor-pointer transition border border-white/10 shadow-lg"
                    id="btn-connection-staff"
                  >
                    <Crown className="w-4 h-4 text-amber-400" />
                    <span>Connexion en tant que Staff</span>
                  </button>
                </div>
              </div>

              {/* Bento Grid d'informations administratives */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass p-6 rounded-2xl border border-white/5 space-y-3">
                  <div className="w-10 h-10 rounded-lg bg-pink-500/10 flex items-center justify-center text-pink-400">
                    <FileText className="w-5 h-5" />
                  </div>
                  <h3 className="font-display font-bold text-slate-200">1. Dossier Structuré</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Saisissez vos disponibilités, vos expériences sur Roblox et répondez à notre cas pratique d’arbitrage en jeu.
                  </p>
                </div>

                <div className="glass p-6 rounded-2xl border border-white/5 space-y-3">
                  <div className="w-10 h-10 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                    <Radio className="w-5 h-5" />
                  </div>
                  <h3 className="font-display font-bold text-slate-200">2. EventStream Link</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Observez le statut de votre candidature s'actualiser en temps réel lorsque notre Secrétariat Fondation l'étudie en direct.
                  </p>
                </div>

                <div className="glass p-6 rounded-2xl border border-white/5 space-y-3">
                  <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
                    <ShieldAlert className="w-5 h-5" />
                  </div>
                  <h3 className="font-display font-bold text-slate-200">3. Audit & Transparence</h3>
                  <p className="text-xs text-slate-400 leading-relaxed">
                    Chaque action des recruteurs est enregistrée dans nos registres immuables, garantissant une impartialité totale.
                  </p>
                </div>
              </div>

              {/* Active server status banner */}
              <div className="p-4.5 bg-emerald-500/5 border border-emerald-500/15 rounded-2xl flex flex-col sm:flex-row justify-between items-center gap-4 text-xs">
                <div className="flex items-center gap-3">
                  <span className="relative flex h-3 w-3 shrink-0">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
                  </span>
                  <span className="text-slate-300 font-mono">STATUT DES ADMISSIONS AMSTERDAM RP : <strong className="text-emerald-400 font-bold">RECRUTEMENTS ACTIFS (EMERGENCY HAMBURG)</strong></span>
                </div>
                <div className="text-slate-400 font-mono text-[11px]">Délai d'étude estimé : 24 heures maximum</div>
              </div>
            </div>
          )
        ) : (
          /* 4. Dashboard connecté */
          <div className="space-y-6 animate-fade-in">

            {/* Statistiques d'admission pour Gérants et Fondations */}
            {(currentUser.role === 'gerant' || currentUser.role === 'fondation') && dashboardStats && (
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4" id="stats-bento-grid">
                <div className="glass p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">Dossiers déposés</span>
                  <span className="text-2xl font-black text-slate-100 font-display">{dashboardStats.total}</span>
                </div>
                <div className="glass p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">⏳ En attente</span>
                  <span className="text-2xl font-black text-yellow-400 font-display">{dashboardStats.pending}</span>
                </div>
                <div className="glass p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">📖 En examen</span>
                  <span className="text-2xl font-black text-blue-400 font-display">{dashboardStats.reading}</span>
                </div>
                <div className="glass p-4 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">✅ Candidats Admis</span>
                  <span className="text-2xl font-black text-emerald-400 font-display">{dashboardStats.accepted}</span>
                </div>
                <div className="glass p-4 rounded-xl space-y-1 col-span-2 md:col-span-1">
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">👥 Effectif Staff total</span>
                  <span className="text-2xl font-black text-indigo-400 font-display">
                    {dashboardStats.modoCount + dashboardStats.adminCount + dashboardStats.gerantCount + dashboardStats.fondationCount}
                  </span>
                </div>
              </div>
            )}

            {/* Barre de navigation des Onglets du CMS */}
            <div className="flex items-center justify-between glass rounded-xl p-1.5 overflow-x-auto" id="cms-tabs-bar">
              <div className="flex items-center gap-1 shrink-0">
                <button
                  onClick={() => setActiveTab('live-hub')}
                  className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 shrink-0 cursor-pointer ${
                    activeTab === 'live-hub'
                      ? 'bg-gradient-to-r from-pink-600 to-indigo-650 border border-white/10 text-slate-100 shadow'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  id="tab-live-hub"
                >
                  <Radio className="w-4 h-4 text-pink-500 animate-pulse animate-duration-1000" />
                  <span>🛰️ Live Hub Amsterdam</span>
                </button>

                <button
                  onClick={() => setActiveTab('candidat')}
                  className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 shrink-0 cursor-pointer ${
                    activeTab === 'candidat'
                      ? 'bg-white/10 border border-white/5 text-slate-100 shadow'
                      : 'text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  id="tab-candidat"
                >
                  <FileText className="w-4 h-4" />
                  <span>Espace Candidat</span>
                </button>

                {currentUser.role !== 'user' && (
                  <button
                    onClick={() => setActiveTab('staff-apps')}
                    className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 shrink-0 cursor-pointer ${
                      activeTab === 'staff-apps'
                        ? 'bg-white/10 border border-white/5 text-slate-100 shadow'
                        : 'text-slate-400 hover:text-white hover:bg-white/5'
                    }`}
                    id="tab-staff-apps"
                  >
                    <Columns className="w-4 h-4" />
                    <span>📂 Candidatures ({applications.length})</span>
                  </button>
                )}

                {currentUser.role === 'fondation' && (
                  <>
                    <button
                      onClick={() => setActiveTab('staff-mgmt')}
                      className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 shrink-0 cursor-pointer ${
                        activeTab === 'staff-mgmt'
                          ? 'bg-white/10 border border-white/5 text-slate-100 shadow'
                          : 'text-slate-400 hover:text-white hover:bg-white/5'
                      }`}
                      id="tab-staff-mgmt"
                    >
                      <Crown className="w-4 h-4" />
                      <span>👑 Gestion Staff</span>
                    </button>

                    <button
                      onClick={() => setActiveTab('logs')}
                      className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-all duration-200 shrink-0 cursor-pointer ${
                        activeTab === 'logs'
                          ? 'bg-white/10 border border-white/5 text-slate-100 shadow'
                          : 'text-slate-400 hover:text-white hover:bg-white/5'
                      }`}
                      id="tab-logs"
                    >
                      <Terminal className="w-4 h-4" />
                      <span>📜 Journaux de Logs</span>
                    </button>
                  </>
                )}
              </div>

              <div className="flex items-center shrink-0 pr-2">
                <button
                  onClick={loadDomainData}
                  disabled={refreshing}
                  className="p-1 px-3.5 bg-white/5 hover:bg-white/10 active:scale-95 text-slate-350 hover:text-white border border-white/10 rounded-lg flex items-center gap-1.5 text-[10px] font-bold tracking-wider uppercase transition-all duration-155 cursor-pointer"
                  id="btn-refresh"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} />
                  <span>Mettre à jour</span>
                </button>
              </div>
            </div>

            {/* 5. Contenus des Onglets */}
            <div className="min-h-[400px]">
              {activeTab === 'live-hub' && (
                <LiveHub
                  currentUser={currentUser}
                  liveMessages={liveMessages}
                  onSendMessage={handleSendLiveMessage}
                  recentEvents={recentEvents}
                />
              )}

              {activeTab === 'candidat' && (
                <CandidatePanel
                  applications={applications.filter(a => a.userId === currentUser.id)}
                  onApplicationSubmitted={loadDomainData}
                  userUsername={currentUser.username}
                />
              )}

              {activeTab === 'staff-apps' && currentUser.role !== 'user' && (
                <StaffApplications
                  applications={applications}
                  userRole={currentUser.role}
                  staffId={currentUser.id}
                  onStatusUpdated={loadDomainData}
                />
              )}

              {activeTab === 'staff-mgmt' && currentUser.role === 'fondation' && (
                <StaffManagement
                  users={usersList}
                  onStaffUpdated={loadDomainData}
                  currentUserId={currentUser.id}
                />
              )}

              {activeTab === 'logs' && currentUser.role === 'fondation' && (
                <AuditLogs logs={moderationLogs} />
              )}
            </div>

          </div>
        )}

      </main>

      <footer className="border-t border-white/5 py-10 text-center text-xs text-slate-400" id="main-footer">
        <div className="max-w-7xl mx-auto px-6 space-y-2">
          <p>© 2026 Amsterdam RP. Plateforme administrative de recrutement développée sous licence ESX.</p>
          <p className="text-[10px] text-slate-550 max-w-sm mx-auto leading-relaxed">
            Ce portail est un produit indépendant de Discord Inc, conçu exclusivement pour la sécurité structurelle et le recrutement des équipes de modération GTA V.
          </p>
        </div>
      </footer>
    </div>
  );
}
